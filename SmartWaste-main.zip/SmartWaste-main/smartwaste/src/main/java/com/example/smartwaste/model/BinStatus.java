package com.example.smartwaste.model;

public enum BinStatus {
    OK,
    NEAR_FULL,
    OVERFLOW
}
