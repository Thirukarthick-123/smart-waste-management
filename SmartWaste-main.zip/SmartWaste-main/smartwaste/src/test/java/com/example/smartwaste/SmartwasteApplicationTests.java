package com.example.smartwaste;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartwasteApplicationTests {

	@Test
	void contextLoads() {
	}

}
