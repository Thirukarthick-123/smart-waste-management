export default function RoutesPage() {
  return (
    <div className="add-card">
      <h3>Optimized Routes</h3>
      <p>🚧 Routes generated using AI Optimization Engine (Backend – Phase 2)</p>
    </div>
  );
}
