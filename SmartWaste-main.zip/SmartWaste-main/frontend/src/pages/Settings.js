export default function Settings() {
  return (
    <div className="add-card">
      <h3>System Settings</h3>
      <ul>
        <li>0–39% → Empty</li>
        <li>40–79% → Partial</li>
        <li>80–100% → Full</li>
      </ul>
    </div>
  );
}
